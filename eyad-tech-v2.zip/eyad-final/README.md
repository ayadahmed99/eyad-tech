# 🚀 EYAD TECH — موقع إياد تيك الكامل

موقع رقمي متكامل مع Firebase Auth + Firestore Orders + لوحة تحكم.

## 📂 محتويات الحزمة

```
eyad-final/
├── index.html           # الصفحة الرئيسية (هيرو + مميزات + من نحن + آراء + CTA)
├── services.html        # صفحة الخدمات + FAQ
├── store.html           # المتجر (شحن ألعاب/بطاقات/إعلانات)
├── packages.html        # الباقات والأسعار
├── about.html           # من نحن (قصة، قيم، رؤية)
├── contact.html         # تواصل + نموذج
├── orders.html          # طلباتي (للمستخدم)
├── admin.html           # لوحة تحكم الإدارة
├── style.css            # ستايل موحد بهوية إياد تيك
├── app.js               # منطق المستخدم (Auth + Orders)
├── admin.js             # منطق الإدارة (تحديث الحالة)
└── BRAND_GUIDELINES.md  # دليل الهوية البصرية الكامل
```

## ⚙️ خطوات التشغيل

### 1. إعداد Firebase
1. أنشئ مشروعًا في [Firebase Console](https://console.firebase.google.com)
2. فعّل **Authentication > Phone**
3. أنشئ **Firestore Database**
4. انسخ إعدادات `firebaseConfig` إلى **app.js** و **admin.js**

### 2. تعيين الأدمن
في `admin.js` غيّر:
```js
const ADMIN_PHONES = ["+967774181129"]; // ضع رقمك هنا
```

### 3. قواعد Firestore الموصى بها
```
match /orders/{orderId} {
  allow create: if request.auth != null;
  allow read: if request.auth != null && (
    resource.data.userId == request.auth.uid ||
    request.auth.token.phone_number in ['+967774181129']
  );
  allow update: if request.auth.token.phone_number in ['+967774181129'];
}
```

### 4. التشغيل المحلي
```bash
python3 -m http.server 8080
# افتح http://localhost:8080
```

## ✨ المميزات الجديدة

✅ **هوية بصرية كاملة** — Cyber-Aqua + Electric Blue + Deep Space
✅ **شعار احترافي** مع نسخ متعددة
✅ **8 صفحات** متناسقة بهوية موحدة
✅ **تسجيل دخول بالهاتف** عبر OTP
✅ **نظام طلبات حقيقي** مع Firestore
✅ **تحديث الحالة لحظيًا** (pending → processing → completed)
✅ **لوحة تحكم احترافية** للإدارة مع إحصائيات وفلاتر
✅ **متجر منظم** بـ 12+ منتجًا
✅ **آراء العملاء** + **خطوات العمل** + **FAQ**
✅ **متجاوب 100%** على الجوال والديسكتوب

## 🎨 لوحة الألوان

| اللون | HEX |
|------|-----|
| Cyan Electric | `#00E0FF` |
| Electric Blue | `#4F8DFF` |
| Mint Pulse | `#00FFB2` |
| Tech Violet | `#7C5CFF` |
| Deep Space | `#03070F` |

## 📞 التواصل
- 📱 +967 774181129
- 📧 ayadalmusiple@gmail.com
- 💬 wa.me/967774181129
