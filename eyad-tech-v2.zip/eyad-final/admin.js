/* ================================================================
   EYAD TECH — Admin Panel Logic
   ================================================================ */
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import {
  getAuth, RecaptchaVerifier, signInWithPhoneNumber, onAuthStateChanged, signOut
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";
import {
  getFirestore, collection, doc, updateDoc, onSnapshot, query, orderBy
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT.appspot.com",
  messagingSenderId: "XXXXXXXXX",
  appId: "1:XXXXX:web:XXXXX"
};

// ⚠️ ضع رقم هاتفك كأدمن (يبدأ بـ + ودون مسافات)
const ADMIN_PHONES = ["+967774181129"];

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

let confirmationResult = null;
let allOrders = [];
let currentFilter = 'all';

function toast(msg, type='info'){
  const t = document.getElementById('toast');
  if(!t) return;
  t.textContent = msg;
  t.className = 'toast show ' + (type === 'error' ? 'error' : type === 'success' ? 'success' : '');
  setTimeout(()=> t.className = 'toast', 3500);
}

/* ====== Admin Login ====== */
window.adminSendOTP = async function(){
  const phone = document.getElementById('adminPhone').value.trim();
  if(!ADMIN_PHONES.includes(phone)){
    toast('هذا الرقم غير مصرح له بالدخول ❌', 'error');
    return;
  }
  if(!window.recaptcha){
    window.recaptcha = new RecaptchaVerifier(auth, 'adminRecaptcha', { size: 'normal' });
    window.recaptcha.render();
  }
  try {
    confirmationResult = await signInWithPhoneNumber(auth, phone, window.recaptcha);
    document.getElementById('adminOTPArea').classList.remove('hidden');
    toast('تم إرسال رمز التحقق ✅', 'success');
  } catch(e){
    toast('فشل: ' + e.message, 'error');
  }
};

window.adminVerifyOTP = async function(){
  const code = document.getElementById('adminOTP').value.trim();
  try {
    await confirmationResult.confirm(code);
    toast('مرحبًا أيها المسؤول 👑', 'success');
  } catch(e){
    toast('رمز خاطئ', 'error');
  }
};

window.adminLogout = function(){
  if(confirm('تسجيل الخروج؟')) signOut(auth).then(()=>location.reload());
};

/* ====== Auth State ====== */
onAuthStateChanged(auth, (user) => {
  if(user && ADMIN_PHONES.includes(user.phoneNumber)){
    document.getElementById('adminLogin').classList.add('hidden');
    document.getElementById('adminDashboard').classList.remove('hidden');
    loadAllOrders();
  } else {
    document.getElementById('adminLogin').classList.remove('hidden');
    document.getElementById('adminDashboard').classList.add('hidden');
  }
});

/* ====== Load All Orders (Live) ====== */
function loadAllOrders(){
  const q = query(collection(db, 'orders'), orderBy('createdAt', 'desc'));
  onSnapshot(q, (snap) => {
    allOrders = [];
    snap.forEach(d => allOrders.push({ id: d.id, ...d.data() }));
    renderOrders();
    updateStats();
  });
}

function updateStats(){
  document.getElementById('statTotal').textContent = allOrders.length;
  document.getElementById('statPending').textContent = allOrders.filter(o => o.status === 'pending').length;
  document.getElementById('statProcessing').textContent = allOrders.filter(o => o.status === 'processing').length;
  document.getElementById('statCompleted').textContent = allOrders.filter(o => o.status === 'completed').length;
}

window.filterOrders = function(status, btn){
  currentFilter = status;
  document.querySelectorAll('.filter-bar button').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  renderOrders();
};

function renderOrders(){
  const tbody = document.getElementById('adminOrdersBody');
  const list = currentFilter === 'all' ? allOrders : allOrders.filter(o => o.status === currentFilter);

  if(list.length === 0){
    tbody.innerHTML = `<tr><td colspan="6" style="text-align:center;padding:40px;color:var(--muted);">لا توجد طلبات</td></tr>`;
    return;
  }

  const statusMap = {
    pending: 'قيد الانتظار',
    processing: 'قيد التنفيذ',
    completed: 'مكتمل',
    cancelled: 'ملغي'
  };

  tbody.innerHTML = list.map((o, i) => {
    const date = o.createdAt?.toDate?.().toLocaleString('ar-EG') || '—';
    return `
      <tr>
        <td>${i+1}</td>
        <td>${date}</td>
        <td><strong>${o.product}</strong></td>
        <td><a href="tel:${o.phone}" style="color:var(--brand-primary);">${o.phone || '—'}</a></td>
        <td><span class="o-status ${o.status}">${statusMap[o.status] || o.status}</span></td>
        <td>
          <select class="status-select" onchange="updateStatus('${o.id}', this.value)">
            <option value="pending" ${o.status==='pending'?'selected':''}>قيد الانتظار</option>
            <option value="processing" ${o.status==='processing'?'selected':''}>قيد التنفيذ</option>
            <option value="completed" ${o.status==='completed'?'selected':''}>مكتمل</option>
            <option value="cancelled" ${o.status==='cancelled'?'selected':''}>ملغي</option>
          </select>
        </td>
      </tr>
    `;
  }).join('');
}

window.updateStatus = async function(orderId, newStatus){
  try {
    await updateDoc(doc(db, 'orders', orderId), { status: newStatus });
    toast('تم تحديث الحالة بنجاح ✅', 'success');
  } catch(e){
    toast('فشل التحديث', 'error');
  }
};
