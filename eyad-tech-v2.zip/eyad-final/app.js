/* ================================================================
   EYAD TECH — App Logic (Firebase Auth + Firestore Orders)
   ================================================================ */

// ⚠️ استبدل القيم التالية بإعدادات مشروعك في Firebase Console
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import {
  getAuth, RecaptchaVerifier, signInWithPhoneNumber, onAuthStateChanged, signOut
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";
import {
  getFirestore, collection, addDoc, getDocs, query, where, orderBy, onSnapshot, serverTimestamp
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT.appspot.com",
  messagingSenderId: "XXXXXXXXX",
  appId: "1:XXXXX:web:XXXXX"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

let confirmationResult = null;
let currentUser = null;

/* ============ Toast Helper ============ */
function toast(msg, type='info'){
  const t = document.getElementById('toast');
  if(!t) { alert(msg); return; }
  t.textContent = msg;
  t.className = 'toast show ' + (type === 'error' ? 'error' : type === 'success' ? 'success' : '');
  setTimeout(()=> t.className = 'toast', 3500);
}

/* ============ Auth Modal ============ */
window.openAuth = function(){
  const m = document.getElementById('authModal');
  if(m) m.classList.add('show');
  setupRecaptcha();
};
window.closeAuth = function(){
  const m = document.getElementById('authModal');
  if(m) m.classList.remove('show');
};

function setupRecaptcha(){
  if(window.recaptchaVerifier) return;
  try {
    window.recaptchaVerifier = new RecaptchaVerifier(auth, 'recaptcha-container', {
      size: 'normal',
      callback: () => {}
    });
    window.recaptchaVerifier.render();
  } catch(e){ console.warn('reCAPTCHA setup:', e); }
}

window.sendOTP = async function(){
  const phone = document.getElementById('phoneInput').value.trim();
  if(!phone.startsWith('+')) { toast('الرجاء إدخال رقم بصيغة دولية مثل +967...', 'error'); return; }
  try {
    confirmationResult = await signInWithPhoneNumber(auth, phone, window.recaptchaVerifier);
    document.getElementById('authStep1').classList.add('hidden');
    document.getElementById('authStep2').classList.remove('hidden');
    toast('تم إرسال رمز التحقق إلى هاتفك ✅', 'success');
  } catch(e){
    console.error(e);
    toast('فشل الإرسال: ' + (e.message || 'حاول مجددًا'), 'error');
  }
};

window.verifyOTP = async function(){
  const code = document.getElementById('otpInput').value.trim();
  if(!code) { toast('أدخل رمز التحقق', 'error'); return; }
  try {
    const result = await confirmationResult.confirm(code);
    currentUser = result.user;
    toast('مرحبًا بك في إياد تيك 🎉', 'success');
    closeAuth();
    updateUIAfterLogin();
  } catch(e){
    toast('رمز خاطئ، حاول مجددًا', 'error');
  }
};

/* ============ Auth State ============ */
onAuthStateChanged(auth, (user) => {
  currentUser = user;
  updateUIAfterLogin();
  if(user && document.getElementById('ordersList')){
    loadUserOrders();
  }
});

function updateUIAfterLogin(){
  const btn = document.getElementById('loginBtn');
  if(btn){
    if(currentUser){
      btn.textContent = currentUser.phoneNumber ? '👤 ' + currentUser.phoneNumber : 'حسابي';
      btn.onclick = () => {
        if(confirm('تسجيل الخروج؟')) signOut(auth).then(()=>location.reload());
      };
    } else {
      btn.textContent = 'دخول';
      btn.onclick = openAuth;
    }
  }
  const prompt = document.getElementById('loginPrompt');
  if(prompt && currentUser) prompt.classList.add('hidden');
}

/* ============ Orders ============ */
window.order = async function(product){
  if(!currentUser){
    toast('سجّل الدخول أولاً لإتمام الطلب 🔒', 'error');
    openAuth();
    return;
  }
  try {
    const orderData = {
      userId: currentUser.uid,
      phone: currentUser.phoneNumber,
      product: product,
      status: 'pending',
      createdAt: serverTimestamp()
    };
    const docRef = await addDoc(collection(db, 'orders'), orderData);
    toast('✅ تم استلام طلبك: ' + product, 'success');
    console.log('Order ID:', docRef.id);
    setTimeout(()=> location.href = 'orders.html', 1200);
  } catch(e){
    console.error(e);
    toast('حدث خطأ، حاول مجددًا', 'error');
  }
};

/* ============ Load User Orders (Real-time) ============ */
async function loadUserOrders(){
  if(!currentUser) return;
  const list = document.getElementById('ordersList');
  const empty = document.getElementById('emptyOrders');
  const userInfo = document.getElementById('userInfo');
  if(userInfo) userInfo.textContent = '👤 ' + currentUser.phoneNumber;

  const q = query(
    collection(db, 'orders'),
    where('userId', '==', currentUser.uid),
    orderBy('createdAt', 'desc')
  );

  onSnapshot(q, (snap) => {
    list.innerHTML = '';
    if(snap.empty){
      list.classList.add('hidden');
      empty?.classList.remove('hidden');
      return;
    }
    list.classList.remove('hidden');
    empty?.classList.add('hidden');

    snap.forEach(doc => {
      const d = doc.data();
      const date = d.createdAt?.toDate?.().toLocaleString('ar-EG') || '—';
      const statusMap = {
        pending: { label: 'قيد الانتظار', cls: 'pending' },
        processing: { label: 'قيد التنفيذ', cls: 'processing' },
        completed: { label: 'مكتمل ✓', cls: 'completed' },
        cancelled: { label: 'ملغي', cls: 'cancelled' }
      };
      const s = statusMap[d.status] || statusMap.pending;
      list.insertAdjacentHTML('beforeend', `
        <div class="order-item">
          <div>
            <div class="o-product">${d.product}</div>
            <div class="o-meta">رقم الطلب: ${doc.id.slice(0,8)} • ${date}</div>
          </div>
          <span class="o-status ${s.cls}">${s.label}</span>
          <a class="btn btn-ghost" href="https://wa.me/967774181129?text=استفسار عن الطلب ${doc.id.slice(0,8)}" target="_blank">💬 متابعة</a>
        </div>
      `);
    });
  });
}
